
import java.util.Date;


public class Practica {
	Alumne alumne;
	Cotxe cotxe;
	Date data;
	int km;
	Float val;
	public Alumne getAlumne() {
		return alumne;
	}
	public void setAlumne(Alumne alumne) {
		this.alumne = alumne;
	}
	public Cotxe getCotxe() {
		return cotxe;
	}
	public void setCotxe(Cotxe cotxe) {
		this.cotxe = cotxe;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public int getKm() {
		return km;
	}
	public void setKm(int km) {
		this.km = km;
	}
	public Float getVal() {
		return val;
	}
	public void setVal(Float val) {
		this.val = val;
	}  
}

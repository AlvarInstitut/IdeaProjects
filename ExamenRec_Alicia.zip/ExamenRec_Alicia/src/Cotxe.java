
import java.util.Date;


public class Cotxe {
	String matricula;
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Date getData_c() {
		return data_c;
	}
	public void setData_c(Date data_c) {
		this.data_c = data_c;
	}
	public int getKm() {
		return km;
	}
	public void setKm(int km) {
		this.km = km;
	}
	String model;
	Date data_c;
	int km;
}
